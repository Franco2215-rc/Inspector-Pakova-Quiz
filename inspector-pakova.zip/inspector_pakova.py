import tkinter as tk
from tkinter import messagebox

try:
    from PIL import Image, ImageTk
    PIL_DISPONIBLE = True
except ImportError:
    PIL_DISPONIBLE = False

# ==========================
# PALETA DE COLORES
# ==========================
NEGRO = "#0B0B0D"
NEGRO_CLARO = "#17171B"
GRIS_PANEL = "#232329"
GRIS_TEXTO = "#B7B7C2"

AMARILLO = "#FFD600"
AMARILLO_HOVER = "#FFE457"
AMARILLO_OSCURO = "#C9A600"

BLANCO = "#F7F7FA"

VERDE = "#00C853"
VERDE_HOVER = "#20E070"

ROJO = "#FF1744"
ROJO_HOVER = "#FF4D6D"

FUENTE_TITULO = ("Segoe UI", 24, "bold")
FUENTE_SUBTITULO = ("Segoe UI", 14)
FUENTE_GRANDE = ("Segoe UI", 34, "bold")

PUNTOS_MISION = 50
PUNTOS_FINAL = 100
VIDAS_INICIALES = 3

# ==========================
# MISIONES (datos, no código)
# ==========================
# Tipos:
#   "bug_o_no"  -> se muestra una pantalla y el jugador decide si es bug o no
#   "opciones"  -> pregunta con varias opciones (una correcta)
MISIONES = [
    {
        "tipo": "bug_o_no",
        "titulo": "🛒 MISIÓN 1 - ¿BUG O NO BUG?",
        "tarjeta": "Tienda Online",
        "lineas": [
            ("Producto: Mochila", False),
            ("Precio: $500", False),
            ("Cantidad: 2", False),
            ("Total a pagar: $100", True),
        ],
        "es_bug": True,
        "msg_ok": "¡Correcto! 2 productos de $500 nunca pueden costar $100 en total.",
        "msg_error": "Revisa la cuenta: 2 x $500 no da $100.",
    },
    {
        "tipo": "bug_o_no",
        "titulo": "❓ MISIÓN 2 - ¿BUG O NO BUG?",
        "tarjeta": "Sistema Escolar",
        "lineas": [
            ("Matemática: 8", False),
            ("Historia: 7", False),
            ("Promedio: 15", True),
        ],
        "es_bug": True,
        "msg_ok": "¡Correcto! El promedio de 8 y 7 nunca puede dar 15.",
        "msg_error": "Ese promedio es imposible: (8 + 7) / 2 = 7.5.",
    },
    {
        "tipo": "bug_o_no",
        "titulo": "📅 MISIÓN 3 - ¿BUG O NO BUG?",
        "tarjeta": "Calendario de Eventos",
        "lineas": [
            ("Evento: Fiesta escolar", False),
            ("Fecha: 30 de febrero", True),
            ("Hora: 18:00", False),
        ],
        "es_bug": True,
        "msg_ok": "¡Correcto! El 30 de febrero no existe en el calendario.",
        "msg_error": "Mira bien la fecha: febrero nunca tiene 30 días.",
    },
    {
        "tipo": "bug_o_no",
        "titulo": "🔒 MISIÓN 4 - ¿BUG O NO BUG?",
        "tarjeta": "Perfil de Usuario",
        "lineas": [
            ("Nombre: Franco", False),
            ("Email: franco@email.com", False),
            ("Contraseña: 123456", True),
        ],
        "es_bug": True,
        "msg_ok": "¡Correcto! Las contraseñas nunca deben mostrarse en pantalla.",
        "msg_error": "Hay un problema de seguridad: la contraseña está visible.",
    },
    {
        "tipo": "bug_o_no",
        "titulo": "🎂 MISIÓN 5 - ¿BUG O NO BUG?",
        "tarjeta": "Registro de Alumno",
        "lineas": [
            ("Nombre: Sofía", False),
            ("Edad: -5 años", True),
            ("Curso: 1° A", False),
        ],
        "es_bug": True,
        "msg_ok": "¡Correcto! Nadie puede tener una edad negativa.",
        "msg_error": "Fíjate en la edad: -5 años es imposible.",
    },
    {
        "tipo": "bug_o_no",
        "titulo": "✅ MISIÓN 6 - ¿BUG O NO BUG?",
        "tarjeta": "Boleto de Cine",
        "lineas": [
            ("Película: Aventura Espacial", False),
            ("Entradas: 3", False),
            ("Precio c/u: $200", False),
            ("Total: $600", False),
        ],
        "es_bug": False,
        "msg_ok": "¡Correcto! Aquí no hay ningún error: 3 x $200 = $600.",
        "msg_error": "Revisa de nuevo: la cuenta 3 x $200 = $600 está bien.",
    },
    {
        "tipo": "opciones",
        "titulo": "💾 MISIÓN 7 - ELIGE BIEN",
        "pregunta": "Un botón dice 'Gaurdar' en vez de 'Guardar'. ¿Qué tipo de error es?",
        "opciones": [
            ("Un error de ortografía en la pantalla", True),
            ("No es un error, así se escribe", False),
            ("Un problema de internet", False),
        ],
        "msg_ok": "¡Correcto! Los errores de texto también son bugs que un tester reporta.",
        "msg_error": "Piensa de nuevo: 'Gaurdar' está mal escrito.",
    },
    {
        "tipo": "opciones",
        "titulo": "🐞 MISIÓN 8 - ELIGE BIEN",
        "pregunta": "Si encuentras un bug en una app, ¿qué debe hacer un buen tester?",
        "opciones": [
            ("Ignorarlo, no es su problema", False),
            ("Reportarlo con detalles para que lo arreglen", True),
            ("Borrar la app", False),
        ],
        "msg_ok": "¡Correcto! Reportar el bug con detalles ayuda a mejorar el software.",
        "msg_error": "Un tester nunca ignora los errores: los reporta.",
    },
    {
        "tipo": "opciones",
        "titulo": "🏆 MISIÓN FINAL",
        "pregunta": "¿Qué hace un tester?",
        "opciones": [
            ("Rompe programas", False),
            ("Busca errores para mejorar la calidad", True),
            ("Solo juega videojuegos", False),
        ],
        "msg_ok": "¡Exacto! El tester busca errores para mejorar la calidad del software.",
        "msg_error": "El tester ayuda a mejorar el software, no a romperlo.",
        "puntos": PUNTOS_FINAL,
    },
]


class InspectorPakova:
    def __init__(self, root):
        self.root = root
        self.root.title("Inspector Pakova 🕵️")
        self.root.configure(bg=NEGRO)
        self.root.attributes("-fullscreen", True)
        self.root.bind("<Escape>", lambda e: self.root.attributes("-fullscreen", False))

        self.ancho = self.root.winfo_screenwidth()
        self.alto = self.root.winfo_screenheight()

        self.logo_barra = self._cargar_imagen("inspectorpakova/assets/logo_pakova.png", (60, 60))
        self.logo = self._cargar_imagen("inspectorpakova/assets/logo_pakova.png", (180, 180))
        icono = self._cargar_imagen("inspectorpakova/assets/logo_pakova.png", (32, 32))
        if icono is not None:
            try:
                self.root.iconphoto(True, icono)
            except Exception as e:
                print("Error cargando icono:", e)
        self.icono = icono

        self.puntos = 0
        self.vidas = VIDAS_INICIALES
        self.mision_actual = 0
        self.total_misiones = len(MISIONES)

        self.menu_principal()

    # ==========================
    # UTILIDADES
    # ==========================
    def _cargar_imagen(self, ruta, tamano):
        if not PIL_DISPONIBLE:
            return None
        try:
            img = Image.open(ruta).resize(tamano)
            return ImageTk.PhotoImage(img)
        except Exception as e:
            print(f"Error cargando imagen {ruta}:", e)
            return None

    def crear_boton(self, parent, texto, comando, bg=AMARILLO, fg=NEGRO,
                    hover_bg=AMARILLO_HOVER, font_size=16, padx=24, pady=12, width=None):
        btn = tk.Button(
            parent, text=texto, command=comando,
            bg=bg, fg=fg, activebackground=hover_bg, activeforeground=fg,
            font=("Segoe UI", font_size, "bold"),
            relief="flat", bd=0, cursor="hand2",
            padx=padx, pady=pady, width=width,
        )
        btn.bind("<Enter>", lambda e: btn.config(bg=hover_bg))
        btn.bind("<Leave>", lambda e: btn.config(bg=bg))
        return btn

    def redondeado(self, canvas, x1, y1, x2, y2, radio=18, **kwargs):
        puntos = [
            x1 + radio, y1, x2 - radio, y1, x2, y1, x2, y1 + radio,
            x2, y2 - radio, x2, y2, x2 - radio, y2, x1 + radio, y2,
            x1, y2, x1, y2 - radio, x1, y1 + radio, x1, y1,
        ]
        return canvas.create_polygon(puntos, smooth=True, **kwargs)

    def limpiar(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def dibujar_fondo(self):
        self.canvas.configure(bg=NEGRO_CLARO)
        self.canvas.create_rectangle(0, 0, self.ancho, self.alto, fill=NEGRO_CLARO, outline="")
        self.canvas.create_rectangle(0, 0, self.ancho, 6, fill=AMARILLO, outline="")

    # ==========================
    # MENÚ PRINCIPAL
    # ==========================
    def menu_principal(self):
        self.limpiar()
        canvas = tk.Canvas(self.root, width=self.ancho, height=self.alto, bg=NEGRO, highlightthickness=0)
        canvas.pack(fill="both", expand=True)

        cx = self.ancho // 2

        canvas.create_rectangle(0, 0, self.ancho, 70, fill=AMARILLO, outline="")
        canvas.create_rectangle(0, 70, self.ancho, 74, fill=AMARILLO_OSCURO, outline="")
        canvas.create_text(30, 35, text="🕵️ INSPECTOR PAKOVA", fill=NEGRO,
                           font=("Segoe UI", 16, "bold"), anchor="w")

        self.redondeado(canvas, cx - 480, 140, cx + 480, 660,
                        radio=28, fill=NEGRO_CLARO, outline=GRIS_PANEL, width=2)

        if self.logo:
            canvas.create_image(cx - 300, 250, image=self.logo)

        canvas.create_text(cx + 300, 220, text="🐞", fill=AMARILLO, font=("Segoe UI Emoji", 90))
        canvas.create_text(cx + 300, 330, text="⚠️", fill=AMARILLO, font=("Segoe UI Emoji", 70))

        canvas.create_text(cx, 380, text="INSPECTOR PAKOVA", fill=AMARILLO, font=FUENTE_GRANDE)
        canvas.create_text(cx, 440, text="Encuentra bugs antes que los usuarios",
                           fill=BLANCO, font=("Segoe UI", 18))
        canvas.create_text(cx, 470, text="Encuentra errores antes de que lleguen a los usuarios",
                           fill=GRIS_TEXTO, font=("Segoe UI", 15))

        self.redondeado(canvas, cx - 220, 500, cx + 220, 540, radio=20, fill=NEGRO, outline="")
        canvas.create_text(
            cx, 520,
            text=f"{self.total_misiones} Misiones  •  {VIDAS_INICIALES} Vidas  •  Muchos Bugs",
            fill=AMARILLO, font=("Segoe UI", 14, "bold")
        )

        boton_jugar = self.crear_boton(
            self.root, "🚀 COMENZAR MISIÓN", self.iniciar_juego,
            bg=AMARILLO, fg=NEGRO, hover_bg=AMARILLO_HOVER, font_size=16, width=22
        )
        canvas.create_window(cx, 600, window=boton_jugar)

        canvas.create_text(
            cx, 635,
            text="Presiona ESC en cualquier momento para salir de pantalla completa",
            fill=GRIS_TEXTO, font=("Segoe UI", 10)
        )

    # ==========================
    # JUEGO
    # ==========================
    def iniciar_juego(self):
        self.puntos = 0
        self.vidas = VIDAS_INICIALES
        self.mision_actual = 0
        self.pantalla_juego()

    def pantalla_juego(self):
        self.limpiar()

        self.barra = tk.Canvas(self.root, width=self.ancho, height=80, bg=AMARILLO, highlightthickness=0)
        self.barra.pack(fill="x")
        self.barra.create_rectangle(0, 78, self.ancho, 80, fill=AMARILLO_OSCURO, outline="")

        if self.logo_barra:
            self.barra.create_image(40, 40, image=self.logo_barra)

        # Puntos
        self.redondeado(self.barra, 110, 20, 250, 60, radio=20, fill=NEGRO, outline="")
        self.txt_puntos = self.barra.create_text(180, 40, text=f"⭐ {self.puntos}",
                                                 fill=AMARILLO, font=("Segoe UI", 14, "bold"))
        # Vidas
        self.redondeado(self.barra, 280, 20, 460, 60, radio=20, fill=NEGRO, outline="")
        self.txt_vidas = self.barra.create_text(370, 40, text="❤️" * self.vidas,
                                                fill=ROJO, font=("Segoe UI", 14, "bold"))
        # Progreso
        self.redondeado(self.barra, self.ancho - 240, 20, self.ancho - 40, 60,
                        radio=20, fill=NEGRO, outline="")
        self.txt_prueba = self.barra.create_text(self.ancho - 140, 40, text="",
                                                 fill=BLANCO, font=("Segoe UI", 14, "bold"))

        self.canvas = tk.Canvas(self.root, bg=NEGRO_CLARO, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        self.cargar_mision()

    def actualizar_puntos(self):
        self.barra.itemconfig(self.txt_puntos, text=f"⭐ {self.puntos}")

    def actualizar_vidas(self):
        self.barra.itemconfig(self.txt_vidas, text="❤️" * max(self.vidas, 0))

    def actualizar_prueba(self, texto):
        self.barra.itemconfig(self.txt_prueba, text=texto)

    # ==========================
    # CARGA GENÉRICA DE MISIONES
    # ==========================
    def cargar_mision(self):
        if self.mision_actual >= self.total_misiones:
            self.pantalla_victoria()
            return

        mision = MISIONES[self.mision_actual]
        self._botones_activos = []

        self.canvas.delete("all")
        self.dibujar_fondo()
        self.actualizar_prueba(f"Prueba {self.mision_actual + 1}/{self.total_misiones}")

        if mision["tipo"] == "bug_o_no":
            self._mostrar_bug_o_no(mision)
        elif mision["tipo"] == "opciones":
            self._mostrar_opciones(mision)

    def _mostrar_bug_o_no(self, mision):
        cx = self.ancho // 2

        self.canvas.create_text(cx, 50, text=mision["titulo"], fill=AMARILLO, font=FUENTE_TITULO)
        self.canvas.create_text(cx, 100, text="Observa la pantalla y decide: ¿hay un bug?",
                                fill=GRIS_TEXTO, font=FUENTE_SUBTITULO)

        alto_tarjeta = 160 + len(mision["lineas"]) * 50
        self.redondeado(self.canvas, cx - 320, 150, cx + 320, 150 + alto_tarjeta,
                        radio=16, fill="white", outline="")
        self.canvas.create_text(cx, 200, text=mision["tarjeta"], font=("Segoe UI", 20, "bold"))

        y = 270
        for texto, es_sospechoso in mision["lineas"]:
            color = ROJO if (es_sospechoso and mision["es_bug"]) else NEGRO
            fuente = ("Segoe UI", 18, "bold") if es_sospechoso else ("Segoe UI", 16)
            self.canvas.create_text(cx, y, text=texto, fill=color, font=fuente)
            y += 50

        y_botones = 150 + alto_tarjeta + 70

        btn_bug = self.crear_boton(
            self.root, "✅ ES UN BUG",
            lambda: self._responder(mision, respuesta_es_bug=True),
            bg=VERDE, fg="white", hover_bg=VERDE_HOVER, font_size=14
        )
        btn_nobug = self.crear_boton(
            self.root, "❌ NO ES BUG",
            lambda: self._responder(mision, respuesta_es_bug=False),
            bg=ROJO, fg="white", hover_bg=ROJO_HOVER, font_size=14
        )
        self._botones_activos = [btn_bug, btn_nobug]
        self.canvas.create_window(cx - 180, y_botones, window=btn_bug)
        self.canvas.create_window(cx + 180, y_botones, window=btn_nobug)

    def _mostrar_opciones(self, mision):
        cx = self.ancho // 2

        self.canvas.create_text(cx, 70, text=mision["titulo"], fill=AMARILLO, font=("Segoe UI", 28, "bold"))
        self.canvas.create_text(cx, 150, text=mision["pregunta"], fill=BLANCO,
                                font=("Segoe UI", 18), width=self.ancho - 200)

        y = 260
        for texto, es_correcta in mision["opciones"]:
            btn = self.crear_boton(
                self.root, texto,
                lambda ok=es_correcta: self._responder(mision, opcion_correcta=ok),
                bg=NEGRO_CLARO, fg=BLANCO, hover_bg=GRIS_PANEL, font_size=14, width=40
            )
            self._botones_activos.append(btn)
            self.canvas.create_window(cx, y, window=btn)
            y += 90

    # ==========================
    # LÓGICA DE RESPUESTAS
    # ==========================
    def _responder(self, mision, respuesta_es_bug=None, opcion_correcta=None):
        if respuesta_es_bug is not None:
            acierto = respuesta_es_bug == mision["es_bug"]
        else:
            acierto = bool(opcion_correcta)

        if acierto:
            self._destruir_botones()
            self.puntos += mision.get("puntos", PUNTOS_MISION)
            self.actualizar_puntos()
            messagebox.showinfo("Correcto", mision["msg_ok"])
            self.mision_actual += 1
            self.cargar_mision()
        else:
            self.vidas -= 1
            self.actualizar_vidas()
            if self.vidas <= 0:
                self._destruir_botones()
                self.pantalla_derrota()
                return
            messagebox.showwarning("Incorrecto", mision["msg_error"])

    def _destruir_botones(self):
        for btn in getattr(self, "_botones_activos", []):
            if btn.winfo_exists():
                btn.destroy()
        self._botones_activos = []

    # ==========================
    # PANTALLAS FINALES
    # ==========================
    def pantalla_victoria(self):
        self.canvas.delete("all")
        self.dibujar_fondo()
        self.actualizar_prueba("Completado")

        cx = self.ancho // 2
        self.canvas.create_text(cx, 180, text="🏆 ¡FELICITACIONES!", fill=VERDE, font=FUENTE_GRANDE)
        self.canvas.create_text(cx, 280, text="Has completado Inspector Pakova",
                                fill=BLANCO, font=("Segoe UI", 24))
        self.canvas.create_text(cx, 380, text=f"Puntaje Final: {self.puntos}",
                                fill=AMARILLO, font=("Segoe UI", 30, "bold"))
        self.canvas.create_text(cx, 480, text="🐞 Ahora ya sabes qué hace un tester",
                                fill=GRIS_TEXTO, font=("Segoe UI", 18))

        btn = self.crear_boton(self.root, "🔄 Jugar de Nuevo", self.iniciar_juego,
                               bg=AMARILLO, fg=NEGRO, hover_bg=AMARILLO_HOVER, font_size=16)
        self.canvas.create_window(cx, 580, window=btn)

    def pantalla_derrota(self):
        self.canvas.delete("all")
        self.dibujar_fondo()
        self.actualizar_prueba("Fin del juego")

        cx = self.ancho // 2
        self.canvas.create_text(cx, 200, text="💔 SIN VIDAS", fill=ROJO, font=FUENTE_GRANDE)
        self.canvas.create_text(cx, 300, text="Los bugs ganaron esta vez...",
                                fill=BLANCO, font=("Segoe UI", 22))
        self.canvas.create_text(cx, 380, text=f"Puntaje alcanzado: {self.puntos}",
                                fill=AMARILLO, font=("Segoe UI", 24, "bold"))
        self.canvas.create_text(
            cx, 450,
            text=f"Llegaste a la misión {self.mision_actual + 1} de {self.total_misiones}",
            fill=GRIS_TEXTO, font=("Segoe UI", 16)
        )

        btn_reintentar = self.crear_boton(self.root, "🔄 Reintentar", self.iniciar_juego,
                                          bg=VERDE, fg="white", hover_bg=VERDE_HOVER, font_size=16)
        btn_menu = self.crear_boton(self.root, "🏠 Menú Principal", self.menu_principal,
                                    bg=AMARILLO, fg=NEGRO, hover_bg=AMARILLO_HOVER, font_size=16)
        self.canvas.create_window(cx - 140, 560, window=btn_reintentar)
        self.canvas.create_window(cx + 140, 560, window=btn_menu)


if __name__ == "__main__":
    root = tk.Tk()
    juego = InspectorPakova(root)
    root.mainloop()
